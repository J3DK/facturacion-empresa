export const dynamic = "force-dynamic";

import InvoiceGenerator from "@/components/InvoiceGenerator";

export default function InvoicesPage() {
  return <InvoiceGenerator />;
}
