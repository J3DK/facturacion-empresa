export const dynamic = "force-dynamic";

import Dashboard from "@/components/Dashboard";

export default function DashboardPage() {
  return <Dashboard />;
}
