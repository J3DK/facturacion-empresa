export const dynamic = "force-dynamic";

import ExpenseTracker from "@/components/ExpenseTracker";

export default function ExpensesPage() {
  return <ExpenseTracker />;
}
